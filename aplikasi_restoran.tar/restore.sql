--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.userr DROP CONSTRAINT userr_pkey;
ALTER TABLE ONLY public.transaksi DROP CONSTRAINT transaksi_pkey;
ALTER TABLE ONLY public.orderr DROP CONSTRAINT orderr_pkey;
ALTER TABLE ONLY public.masakan DROP CONSTRAINT masakan_pkey;
ALTER TABLE ONLY public.level DROP CONSTRAINT level_pkey;
ALTER TABLE ONLY public.detail_order DROP CONSTRAINT detail_order_pkey;
DROP TABLE public.userr;
DROP TABLE public.transaksi;
DROP TABLE public.orderr;
DROP TABLE public.masakan;
DROP TABLE public.level;
DROP TABLE public.detail_order;
DROP TYPE public.stok;
DROP TYPE public.sto;
DROP TYPE public.status_order;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: status_order; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE status_order AS ENUM (
    'selesai',
    'belum'
);


ALTER TYPE status_order OWNER TO postgres;

--
-- Name: sto; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE sto AS ENUM (
    'selesai',
    'belum'
);


ALTER TYPE sto OWNER TO postgres;

--
-- Name: stok; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE stok AS ENUM (
    'tersedia',
    'habis'
);


ALTER TYPE stok OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: detail_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE detail_order (
    id_detail_order character varying(9) NOT NULL,
    id_order character varying(9),
    id_masakan character varying(9),
    keterangan text,
    status_detail_order sto
);


ALTER TABLE detail_order OWNER TO postgres;

--
-- Name: level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE level (
    id_level character varying(9) NOT NULL,
    nama_level character varying(30)
);


ALTER TABLE level OWNER TO postgres;

--
-- Name: masakan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE masakan (
    id_masakan character varying(9) NOT NULL,
    nama_masakan character varying(30),
    harga integer,
    status_masakan stok
);


ALTER TABLE masakan OWNER TO postgres;

--
-- Name: orderr; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE orderr (
    id_order character varying(9) NOT NULL,
    no_meja integer,
    tanggal date,
    id_user character varying(9),
    keterangan character varying(9),
    status_order status_order
);


ALTER TABLE orderr OWNER TO postgres;

--
-- Name: transaksi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE transaksi (
    id_transaksi character varying(9) NOT NULL,
    id_user character varying(9),
    id_order character varying(9),
    tanggal date,
    total_bayar integer
);


ALTER TABLE transaksi OWNER TO postgres;

--
-- Name: userr; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE userr (
    id_user character varying(9) NOT NULL,
    username character varying(30),
    password character varying(9),
    nama_user character varying(30),
    id_level character varying(9)
);


ALTER TABLE userr OWNER TO postgres;

--
-- Data for Name: detail_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY detail_order (id_detail_order, id_order, id_masakan, keterangan, status_detail_order) FROM stdin;
\.
COPY detail_order (id_detail_order, id_order, id_masakan, keterangan, status_detail_order) FROM '$$PATH$$/2835.dat';

--
-- Data for Name: level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY level (id_level, nama_level) FROM stdin;
\.
COPY level (id_level, nama_level) FROM '$$PATH$$/2834.dat';

--
-- Data for Name: masakan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY masakan (id_masakan, nama_masakan, harga, status_masakan) FROM stdin;
\.
COPY masakan (id_masakan, nama_masakan, harga, status_masakan) FROM '$$PATH$$/2836.dat';

--
-- Data for Name: orderr; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY orderr (id_order, no_meja, tanggal, id_user, keterangan, status_order) FROM stdin;
\.
COPY orderr (id_order, no_meja, tanggal, id_user, keterangan, status_order) FROM '$$PATH$$/2833.dat';

--
-- Data for Name: transaksi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY transaksi (id_transaksi, id_user, id_order, tanggal, total_bayar) FROM stdin;
\.
COPY transaksi (id_transaksi, id_user, id_order, tanggal, total_bayar) FROM '$$PATH$$/2831.dat';

--
-- Data for Name: userr; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY userr (id_user, username, password, nama_user, id_level) FROM stdin;
\.
COPY userr (id_user, username, password, nama_user, id_level) FROM '$$PATH$$/2832.dat';

--
-- Name: detail_order detail_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY detail_order
    ADD CONSTRAINT detail_order_pkey PRIMARY KEY (id_detail_order);


--
-- Name: level level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY level
    ADD CONSTRAINT level_pkey PRIMARY KEY (id_level);


--
-- Name: masakan masakan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY masakan
    ADD CONSTRAINT masakan_pkey PRIMARY KEY (id_masakan);


--
-- Name: orderr orderr_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orderr
    ADD CONSTRAINT orderr_pkey PRIMARY KEY (id_order);


--
-- Name: transaksi transaksi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY transaksi
    ADD CONSTRAINT transaksi_pkey PRIMARY KEY (id_transaksi);


--
-- Name: userr userr_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY userr
    ADD CONSTRAINT userr_pkey PRIMARY KEY (id_user);


--
-- PostgreSQL database dump complete
--

